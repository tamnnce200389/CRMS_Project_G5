# CRMS – VNPay Simulation (Demo only)

## Chức năng
- Không kết nối VNPay thật, không tạo URL thanh toán thật, không chuyển tiền.
- Sau khi Customer tạo Booking bằng DepositMethod = `VNPay`, ứng dụng mở `VNPaySimulationPage`.
- Customer có thể chọn mô phỏng `Success`, `Failed` hoặc `Cancelled`.
- Giao dịch được ghi vào bảng `Payments` hiện có với:
  - `PaymentType = Deposit`
  - `PaymentMethod = VNPay`
  - `GatewayTxnRef = DEMO-{BookingCode}`
  - `GatewayTransactionNo = SIM-{BookingId}-{GUID}`
  - `GatewayResponseCode`: `00`, `99`, `24`
  - `Note` ghi rõ DEMO ONLY.
- Chỉ `Success` mới chuyển Booking từ `PendingDeposit` sang `Confirmed` và ghi `BookingStatusHistory`.
- `Failed`/`Cancelled` giữ Booking ở `PendingDeposit`, cho phép thử lại trước hạn cọc.
- Chống ghi nhận thành công lặp lại bằng kiểm tra trạng thái trong transaction.
- My Bookings hiển thị PaymentStatus và có nút mở lại VNPay Demo cho Booking VNPay đang PendingDeposit.

## Các file thay đổi
- `CRMS/Services/DemoPaymentService.cs` (mới)
- `CRMS/Views/Customer/VNPaySimulationPage.xaml` (mới)
- `CRMS/Views/Customer/VNPaySimulationPage.xaml.cs` (mới)
- `CRMS/Views/Customer/BookingPage.xaml.cs`
- `CRMS/Views/Customer/MyBookingsPage.xaml`
- `CRMS/Views/Customer/MyBookingsPage.xaml.cs`
- `CRMS/Services/BookingService.cs`

## Database
Không có migration và không yêu cầu sửa schema. Source hiện có đã khai báo bảng `Payments`, các cột dùng trong demo, FK Booking và các check constraint tương ứng. Cần bảo đảm database thực tế đã có schema `Payments` tương thích với `CRMS.sql`.

## Kiểm thử thủ công
1. Tạo Booking chọn DepositMethod = VNPay.
2. Ứng dụng mở VNPay Demo.
3. Chọn Success: Payment = Success, Booking = Confirmed, có lịch sử trạng thái.
4. Tạo Booking khác và chọn Failed: Payment = Failed, Booking vẫn PendingDeposit.
5. Từ My Bookings mở lại demo và chọn Success: bản ghi Payment được cập nhật, Booking thành Confirmed.
6. Chọn Cancelled: Payment = Cancelled, Booking vẫn PendingDeposit.
7. Nhấn Success nhiều lần hoặc mở lại trang sau khi đã thành công: không tạo thanh toán thành công trùng.
8. Booking không dùng VNPay không được phép vào luồng demo.
