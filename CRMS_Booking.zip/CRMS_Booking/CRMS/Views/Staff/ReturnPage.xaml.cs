
using CRMS.ViewModels;
using System.Windows;
using System.Windows.Controls;

namespace CRMS.Views.Staff
{
    public partial class ReturnPage : Page
    {
        public ReturnPage()
        {
            
        }
    }
}
