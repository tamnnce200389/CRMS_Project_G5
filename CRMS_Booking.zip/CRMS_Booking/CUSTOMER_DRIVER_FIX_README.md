# CRMS – Customer Home & Driver Assignment Fix

## What changed

1. Customer > My Bookings
   - Added a "Trang chủ" button. It invokes the existing MainViewModel Home navigation command.
   - Shows the rental mode in Vietnamese.
   - Shows driver status consistently:
     - SelfDrive -> "Tự lái"
     - WithDriver with no DriverId -> "Đang chờ phân công"
     - WithDriver with DriverId -> driver's FullName loaded through the existing Booking.Driver relationship.

2. Staff > Booking Queue
   - The Staff Dashboard "Bookings" navigation now opens `Views/Staff/BookingQueuePage`.
   - Loads active drivers into a selector.
   - Staff/Admin can select a confirmed WithDriver booking and assign an active driver.
   - The list includes rental type and driver name, and refreshes after assignment.

3. BookingService
   - Added `GetActiveDriversAsync`.
   - Added `AssignDriverAsync`.
   - Uses existing `dbo.usp_AssignDriver` when present (including its Staff/Admin validation and overlap checks).
   - For older databases without that procedure, falls back to EF Core with Staff/Admin validation, transaction, driver application lock, active-driver validation and schedule-conflict checks.
   - Does not add/alter database tables or columns.

## Important business rule

A driver is not assigned at booking creation. `Booking.DriverId` is intentionally nullable and the SQL design comments that the driver is assigned later by Staff for chauffeur rentals. Therefore, a WithDriver booking remains "Đang chờ phân công" until Staff/Admin assigns an active driver to a confirmed booking.

## How to test

1. Open `CRMS.slnx` and Rebuild.
2. Login as Customer and open My Bookings:
   - SelfDrive rows should show "Tự lái".
   - WithDriver rows without assignment should show "Đang chờ phân công".
   - The "Trang chủ" button should return to Customer Home.
3. Login as Staff/Admin.
4. Open Dashboard > "Xem đơn thuê".
5. Select a `Confirmed` booking with rental type `Có tài xế`.
6. Select an active driver and click "Phân công tài xế cho đơn đã chọn".
7. Login as Customer again, refresh My Bookings; the driver's name should appear.

## Validation status

XAML XML parsing passed for the edited XAML files. This environment does not have the .NET SDK or the user's SQL Server, so a real WPF build and database integration test could not be run here.
