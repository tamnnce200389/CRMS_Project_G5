# CRMS Booking fix - 2026-11-03

## What changed
- Booking creation no longer calls `dbo.usp_CreateBooking`.
- The application creates `Bookings` directly through EF Core inside a Serializable transaction.
- `BookingStatus` is explicitly set to `PendingDeposit`; creation no longer depends on a database DEFAULT constraint.
- `BookingStatusHistory` receives the initial `PendingDeposit` event in the same transaction.
- Vehicle reservation uses `sys.sp_getapplock` with resource `CRMS_VEHICLE_{VehicleId}` and checks active/overlapping bookings and maintenance.
- Rental price, driver fee, deposit percentage, and deposit deadline are calculated from `RentalPolicies`.
- `RequestKey` remains the idempotency key to prevent duplicate bookings on retry/double click.
- Voucher is optional: null/empty skips all voucher operations. If a code is supplied, the app checks for `usp_ApplyVoucher` and the voucher tables, then applies it in the same transaction. If voucher support is absent or the code is invalid, the transaction rolls back and no partial booking is left.

## Database
No schema migration or SQL script is required for this code change. The existing database must still contain the mapped CRMS tables/columns and foreign keys used by the application.

## Validation limitation
This environment does not have the .NET SDK, so `dotnet build` and live SQL integration tests could not be run here. Open `CRMS.slnx` in Visual Studio, Rebuild, then test a booking with VoucherCode empty first. After that, test with a valid voucher if the database supports `dbo.usp_ApplyVoucher`.
