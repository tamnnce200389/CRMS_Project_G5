# VNPay navigation fix

## Root cause
The booking UI shown in the user's screenshots is `CRMS/Views/Guest/CarDetailsPage.xaml`, not `CRMS/Views/Customer/BookingPage.xaml`.
`CarSearchPage` opens `CarDetailsPage` using `NavigationService.Navigate(...)`, so after creating a booking, navigation must continue through that same `NavigationService`.

## Change
`CRMS/Views/Guest/CarDetailsPage.xaml.cs` now:
- Reads the selected deposit method after booking creation.
- For VNPay, navigates to `VNPaySimulationPage(id)` using the page's own `NavigationService`.
- Uses `MainViewModel.CurrentPage` only as a fallback.
- Does not create a second booking during navigation.
- Keeps cash flow unchanged.

No database changes.
