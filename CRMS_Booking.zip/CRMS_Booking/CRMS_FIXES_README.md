# CRMS – Bản hoàn thiện toàn bộ phân hệ Booking & Sửa lỗi cấu trúc

## Các mục đã được hoàn thiện trong bản này

1. **Sửa lỗi tráo `x:Class` giữa `Admin/DashboardPage.xaml` và `Staff/StaffDashboardPage.xaml`**:
   - Khôi phục đúng nội dung và `x:Class` cho `CRMS.Views.Admin.DashboardPage` và `CRMS.Views.Staff.StaffDashboardPage` khớp với file `.xaml.cs`.
2. **Sửa quan hệ `Booking` – `Payments` từ `1-1` sang `1-N` chuẩn với `CRMS.sql`**:
   - Cập nhật `Models/Booking.cs` (`ICollection<Payment> Payments`) và `Data/CrmsContext.cs` (`HasMany(p => p.Payments)` kèm filter cho `UX_Payments_OneDepositSuccess`).
   - Giúp luồng hủy đơn đã cọc (`usp_CancelBooking` sinh thêm bản ghi `Refund` `Pending` bên cạnh bản ghi `Deposit` `Success`) hoạt động chính xác, không bị lỗi EF Core hoặc lấy nhầm trạng thái thanh toán.
3. **Đồng bộ múi giờ địa phương (`UTC` -> `LocalTime`) trên toàn bộ danh sách Booking & VNPay**:
   - `BookingService` và `DemoPaymentService` tự động chuyển `StartAt`, `EndAt`, `DepositDeadline` từ giờ UTC trong SQL Server về giờ địa phương khi hiển thị lên `MyBookingsPage`, `BookingQueuePage`, `DriverAssignmentPage` và `VNPaySimulationPage`.
4. **Nâng cấp trang đặt xe `Views/Guest/CarDetailsPage`**:
   - Tự động cộng phí tài xế (`DriverDailyFee` từ bảng `RentalPolicies`) và tính tiền cọc dự kiến (`DepositPercent%`) ngay khi khách chuyển giữa **Tự lái** và **Có tài xế**.
   - Tích hợp bộ chọn **Xem Voucher khả dụng** và nút **Kiểm tra & áp dụng thử** ngay trên `CarDetailsPage`.
5. **Bổ sung Xác nhận cọc tiền mặt (`ConfirmCashDepositAsync`) & Hủy đơn trên `Views/Staff/BookingQueuePage`**:
   - Staff/Admin có thể chọn đơn `PendingDeposit` dùng phương thức `Tiền mặt (Cash)` và bấm **Xác nhận cọc tiền mặt** (gọi `dbo.usp_ConfirmDeposit` hoặc fallback transaction) để chuyển đơn sang `Confirmed`, sau đó phân công tài xế ngay trên cùng màn hình.
6. **Kết nối hoàn chỉnh luồng Đặt xe dài hạn (`LongTermDetailWindow` -> `CarDetailsPage` -> `BookingService.CreateAsync`)**:
   - Khi khách chọn gói `1, 3, 6, 9, 12` tháng trong `LongTermDetailWindow` và bấm **CHỌN THUÊ**, hệ thống chuyển sang `CarDetailsPage` với ngày nhận/trả và tổng tiền gói dài hạn đã chọn (`VehicleLongTermRates`), cho phép đặt xe và thanh toán cọc thật (hỗ trợ tối đa 370 ngày cho gói 12 tháng năm nhuận).
7. **Dọn sạch cấu trúc đóng gói**:
   - Đã xóa thư mục trùng lặp `CRMS_VNPay_CustomerDriver_Fixed/` cùng các thư mục `bin/`, `obj/` thừa.
