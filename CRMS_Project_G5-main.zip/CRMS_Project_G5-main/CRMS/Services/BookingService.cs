using CRMS.Data;
using CRMS.Models;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace CRMS.Services;

public sealed class BookingService
{
    public async Task<List<Vehicle>> GetAvailableVehiclesAsync(DateTime start, DateTime end)
    {
        await using var db = CrmsContextFactory.Create();
        await ExpirePendingAsync(db);
        var busy = db.Bookings.Where(b => b.StartAt < end && b.EndAt > start &&
            (b.BookingStatus == "PendingDeposit" || b.BookingStatus == "Confirmed" || b.BookingStatus == "InUse"))
            .Select(b => b.VehicleId);
        return await db.Vehicles.Where(v => v.OperationalStatus == "Available" && !busy.Contains(v.VehicleId))
            .OrderBy(v => v.Brand).ThenBy(v => v.Model).ToListAsync();
    }

    public async Task<List<Booking>> GetBookingsAsync(long customerId, bool staff, string status)
    {
        await using var db = CrmsContextFactory.Create();
        await ExpirePendingAsync(db);
        var q = db.Bookings.Include(b => b.Vehicle).Include(b => b.Driver).AsQueryable();
        if (!staff) q = q.Where(b => b.CustomerId == customerId);
        if (!string.IsNullOrWhiteSpace(status) && status != "Tất cả") q = q.Where(b => b.BookingStatus == status);
        return await q.OrderByDescending(b => b.CreatedAt).ToListAsync();
    }

    public async Task<long> CreateAsync(long customerId, long vehicleId, DateTime start, DateTime end,
        string rentalType, string depositMethod, string? voucherCode, Guid requestKey)
    {
        if (start < DateTime.Now.AddMinutes(-1) || end <= start) throw new InvalidOperationException("Ngày nhận/trả xe không hợp lệ.");
        await using var db = CrmsContextFactory.Create();
        await using var tx = await db.Database.BeginTransactionAsync(IsolationLevel.Serializable);
        try
        {
            var duplicate = await db.Bookings.FirstOrDefaultAsync(b => b.RequestKey == requestKey);
            if (duplicate != null) { await tx.CommitAsync(); return duplicate.BookingId; }
            await ExpirePendingAsync(db);
            var customer = await db.Users.FirstOrDefaultAsync(u => u.UserId == customerId && u.IsActive);
            if (customer == null) throw new InvalidOperationException("Không tìm thấy khách hàng đang hoạt động.");
            var vehicle = await db.Vehicles.FirstOrDefaultAsync(v => v.VehicleId == vehicleId);
            if (vehicle == null || vehicle.OperationalStatus != "Available") throw new InvalidOperationException("Xe không hoạt động hoặc không tồn tại.");
            var overlap = await db.Bookings.AnyAsync(b => b.VehicleId == vehicleId && b.StartAt < end && b.EndAt > start &&
                (b.BookingStatus == "PendingDeposit" || b.BookingStatus == "Confirmed" || b.BookingStatus == "InUse"));
            if (overlap) throw new InvalidOperationException("Xe đã có đơn trong khoảng thời gian này.");
            var maintenance = await db.MaintenanceRecords.AnyAsync(m => m.VehicleId == vehicleId && m.StartAt < end && m.EndAt > start && m.MaintenanceStatus != "Cancelled");
            if (maintenance) throw new InvalidOperationException("Xe đang trong lịch bảo trì.");
            int days = Math.Max(1, (int)Math.Ceiling((end - start).TotalDays));
            decimal driverRate = 0; long? driverId = null;
            if (rentalType == "WithDriver")
            {
                var driver = await db.Drivers.FirstOrDefaultAsync(d => d.IsActive);
                if (driver == null) throw new InvalidOperationException("Hiện không có tài xế khả dụng.");
                driverId = driver.DriverId;
            }
            decimal vehicleAmount = vehicle.DailyRate * days;
            decimal driverAmount = 0;
            decimal discount = 0; Voucher? voucher = null;
            if (!string.IsNullOrWhiteSpace(voucherCode))
            {
                voucher = await db.Vouchers.FirstOrDefaultAsync(v => v.VoucherCode == voucherCode.Trim() && v.IsActive && v.StartsAt <= DateTime.Now && v.EndsAt >= DateTime.Now);
                if (voucher == null) throw new InvalidOperationException("Voucher không hợp lệ hoặc đã hết hạn.");
                if (vehicleAmount < voucher.MinimumOrderAmount) throw new InvalidOperationException("Đơn chưa đạt giá trị tối thiểu của voucher.");
                int used = await db.BookingVouchers.CountAsync(x => x.VoucherId == voucher.VoucherId && x.RedemptionStatus != "Released");
                if (voucher.UsageLimit.HasValue && used >= voucher.UsageLimit.Value) throw new InvalidOperationException("Voucher đã hết lượt sử dụng.");
                int customerUsed = await db.BookingVouchers.CountAsync(x => x.VoucherId == voucher.VoucherId && x.Booking.CustomerId == customerId && x.RedemptionStatus != "Released");
                if (customerUsed >= voucher.PerCustomerLimit) throw new InvalidOperationException("Bạn đã dùng hết lượt của voucher này.");
                discount = voucher.DiscountType == "Percent" ? vehicleAmount * voucher.DiscountValue / 100m : voucher.DiscountValue;
                if (voucher.MaxDiscountAmount.HasValue) discount = Math.Min(discount, voucher.MaxDiscountAmount.Value);
                discount = Math.Min(vehicleAmount, Math.Max(0, discount));
            }
            decimal total = vehicleAmount + driverAmount - discount;
            var now = DateTime.Now;
            var booking = new Booking { BookingCode = "BK" + Guid.NewGuid().ToString("N")[..10].ToUpper(), RequestKey = requestKey,
                CustomerId = customerId, VehicleId = vehicleId, DriverId = driverId, RentalType = rentalType,
                DepositMethod = depositMethod, StartAt = start, EndAt = end, RentalDays = days,
                VehicleDailyRate = vehicle.DailyRate, DriverDailyRate = driverRate, VehicleAmount = vehicleAmount,
                DriverAmount = driverAmount, DiscountAmount = discount, TotalAmount = total, DepositAmount = Math.Round(total * 0.3m, 2),
                DepositDeadline = now.AddMinutes(30), BookingStatus = "PendingDeposit", CreatedAt = now };
            db.Bookings.Add(booking); await db.SaveChangesAsync();
            db.BookingStatusHistories.Add(new BookingStatusHistory { BookingId = booking.BookingId, OldStatus = null, NewStatus = "PendingDeposit", ChangedByUserId = customerId, ChangedAt = now, ChangeNote = "Tạo booking" });
            if (voucher != null) db.BookingVouchers.Add(new BookingVoucher { BookingId = booking.BookingId, VoucherId = voucher.VoucherId, DiscountSnapshot = discount, RedemptionStatus = "Reserved", CreatedAt = now, AppliedAt = now });
            await db.SaveChangesAsync(); await tx.CommitAsync(); return booking.BookingId;
        }
        catch { await tx.RollbackAsync(); throw; }
    }

    public async Task CancelAsync(long bookingId, long customerId, bool staff, string reason)
    {
        await using var db = CrmsContextFactory.Create();
        await using var tx = await db.Database.BeginTransactionAsync(IsolationLevel.Serializable);
        var b = await db.Bookings.Include(x => x.BookingVoucher).FirstOrDefaultAsync(x => x.BookingId == bookingId);
        if (b == null || (!staff && b.CustomerId != customerId)) throw new InvalidOperationException("Không tìm thấy đơn hoặc bạn không có quyền hủy.");
        if (b.BookingStatus is "InUse" or "Returned" or "Completed" or "Cancelled" or "Expired") throw new InvalidOperationException("Chỉ được hủy đơn trước khi bàn giao xe.");
        if (await db.VehicleHandovers.AnyAsync(h => h.BookingId == bookingId)) throw new InvalidOperationException("Đơn đã bàn giao xe, không thể hủy.");
        var old = b.BookingStatus; var now = DateTime.Now;
        b.BookingStatus = "Cancelled"; b.CancelledAt = now; b.CancelReason = string.IsNullOrWhiteSpace(reason) ? "Khách yêu cầu hủy" : reason.Trim(); b.UpdatedAt = now;
        if (b.BookingVoucher != null) b.BookingVoucher.RedemptionStatus = "Released";
        db.BookingStatusHistories.Add(new BookingStatusHistory { BookingId = b.BookingId, OldStatus = old, NewStatus = "Cancelled", ChangedByUserId = customerId, ChangedAt = now, ChangeNote = b.CancelReason });
        await db.SaveChangesAsync(); await tx.CommitAsync();
    }

    public async Task ExpirePendingAsync(CrmsContext? existing = null)
    {
        bool owns = existing == null; var db = existing ?? CrmsContextFactory.Create();
        try
        {
            var now = DateTime.Now;
            var expired = await db.Bookings.Include(b => b.BookingVoucher).Where(b => b.BookingStatus == "PendingDeposit" && b.DepositDeadline <= now).ToListAsync();
            foreach (var b in expired)
            {
                b.BookingStatus = "Expired"; b.UpdatedAt = now;
                if (b.BookingVoucher != null) b.BookingVoucher.RedemptionStatus = "Released";
                db.BookingStatusHistories.Add(new BookingStatusHistory { BookingId = b.BookingId, OldStatus = "PendingDeposit", NewStatus = "Expired", ChangedAt = now, ChangeNote = "Hết hạn thanh toán cọc" });
            }
            if (expired.Count > 0) await db.SaveChangesAsync();
        }
        finally { if (owns) await db.DisposeAsync(); }
    }
}
