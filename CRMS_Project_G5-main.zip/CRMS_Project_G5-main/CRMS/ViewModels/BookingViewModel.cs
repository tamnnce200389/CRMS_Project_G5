using CRMS.Helpers;
using CRMS.Models;
using CRMS.Services;
using Microsoft.EntityFrameworkCore;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;

namespace CRMS.ViewModels;

public sealed class BookingViewModel : BaseViewModel
{
    private readonly BookingService _service = new();
    private Guid _requestKey = Guid.NewGuid();
    private bool _isBusy;
    private long _customerId;
    private Vehicle? _selectedVehicle;
    private Booking? _selectedBooking;
    private DateTime _startAt = DateTime.Today.AddDays(1).AddHours(9);
    private DateTime _endAt = DateTime.Today.AddDays(2).AddHours(9);
    private string _rentalType = "SelfDrive", _depositMethod = "BANK", _voucherCode = "", _statusFilter = "Tất cả", _message = "Chọn khách hàng, thời gian thuê và xe để đặt đơn.";
    public ObservableCollection<User> Customers { get; } = new();
    public ObservableCollection<Vehicle> Vehicles { get; } = new();
    public ObservableCollection<Booking> Bookings { get; } = new();
    public ObservableCollection<string> Statuses { get; } = new() { "Tất cả", "PendingDeposit", "Confirmed", "InUse", "Returned", "Completed", "Cancelled", "Expired" };
    public ObservableCollection<string> RentalTypes { get; } = new() { "SelfDrive", "WithDriver" };
    public ObservableCollection<string> DepositMethods { get; } = new() { "BANK", "CASH" };
    public ObservableCollection<string> Roles { get; } = new();
    public bool IsBusy { get => _isBusy; set { _isBusy = value; OnPropertyChanged(); CommandManager.InvalidateRequerySuggested(); } }
    public long CustomerId { get => _customerId; set { _customerId = value; OnPropertyChanged(); } }
    public Vehicle? SelectedVehicle { get => _selectedVehicle; set { _selectedVehicle = value; OnPropertyChanged(); OnPropertyChanged(nameof(EstimatedAmount)); } }
    public Booking? SelectedBooking { get => _selectedBooking; set { _selectedBooking = value; OnPropertyChanged(); } }
    public DateTime StartAt { get => _startAt; set { _startAt = value; OnPropertyChanged(); OnPropertyChanged(nameof(EstimatedAmount)); } }
    public DateTime EndAt { get => _endAt; set { _endAt = value; OnPropertyChanged(); OnPropertyChanged(nameof(EstimatedAmount)); } }
    public string RentalType { get => _rentalType; set { _rentalType = value; OnPropertyChanged(); } }
    public string DepositMethod { get => _depositMethod; set { _depositMethod = value; OnPropertyChanged(); } }
    public string VoucherCode { get => _voucherCode; set { _voucherCode = value; OnPropertyChanged(); } }
    public string StatusFilter { get => _statusFilter; set { _statusFilter = value; OnPropertyChanged(); } }
    public string Message { get => _message; set { _message = value; OnPropertyChanged(); } }
    public decimal EstimatedAmount => SelectedVehicle == null || EndAt <= StartAt ? 0 : SelectedVehicle.DailyRate * Math.Max(1, (int)Math.Ceiling((EndAt - StartAt).TotalDays));
    public ICommand RefreshVehiclesCommand { get; }
    public ICommand PlaceBookingCommand { get; }
    public ICommand RefreshBookingsCommand { get; }
    public ICommand CancelBookingCommand { get; }

    public BookingViewModel()
    {
        RefreshVehiclesCommand = new RelayCommand(async _ => await SafeRun(async () => { var list = await _service.GetAvailableVehiclesAsync(StartAt, EndAt); Vehicles.Clear(); foreach (var v in list) Vehicles.Add(v); Message = $"Tìm thấy {list.Count} xe khả dụng."; }));
        PlaceBookingCommand = new RelayCommand(async _ => await PlaceAsync(), _ => !IsBusy && CustomerId > 0 && SelectedVehicle != null);
        RefreshBookingsCommand = new RelayCommand(async _ => await SafeRun(async () => await LoadBookingsAsync()));
        CancelBookingCommand = new RelayCommand(async _ => await SafeRun(async () => { if (SelectedBooking == null) throw new InvalidOperationException("Hãy chọn đơn cần hủy."); await _service.CancelAsync(SelectedBooking.BookingId, CustomerId, false, "Khách yêu cầu hủy từ WPF"); Message = "Đã hủy đơn. Nếu đã thu cọc, TV7 cần xử lý hoàn cọc."; await LoadBookingsAsync(); await LoadVehiclesAsync(); }));
        _ = InitializeAsync();
    }
    private async Task InitializeAsync() => await SafeRun(async () => { await using var db = CRMS.Data.CrmsContextFactory.Create(); var users = await db.Users.Where(u => u.IsActive).OrderBy(u => u.FullName).ToListAsync(); foreach (var u in users) Customers.Add(u); var first = users.FirstOrDefault(u => u.UserRole.Equals("Customer", StringComparison.OrdinalIgnoreCase)); if (first != null) CustomerId = first.UserId; await LoadVehiclesAsync(); await LoadBookingsAsync(); });
    private async Task PlaceAsync() => await SafeRun(async () => { IsBusy = true; long id = await _service.CreateAsync(CustomerId, SelectedVehicle!.VehicleId, StartAt, EndAt, RentalType, DepositMethod, VoucherCode, _requestKey); Message = $"Tạo đơn thành công: BookingId={id}. Trạng thái PendingDeposit, hạn cọc 30 phút."; _requestKey = Guid.NewGuid(); await LoadBookingsAsync(); await LoadVehiclesAsync(); }, true);
    private async Task LoadVehiclesAsync() { var list = await _service.GetAvailableVehiclesAsync(StartAt, EndAt); Vehicles.Clear(); foreach (var v in list) Vehicles.Add(v); }
    private async Task LoadBookingsAsync() { var list = await _service.GetBookingsAsync(CustomerId, false, StatusFilter); Bookings.Clear(); foreach (var b in list) Bookings.Add(b); }
    private async Task SafeRun(Func<Task> action, bool manageBusy = false) { try { if (manageBusy) IsBusy = true; await action(); } catch (Exception ex) { Message = ex.InnerException?.Message ?? ex.Message; MessageBox.Show(Message, "Booking", MessageBoxButton.OK, MessageBoxImage.Warning); } finally { if (manageBusy) IsBusy = false; } }
}
