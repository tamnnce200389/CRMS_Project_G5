using CRMS.ViewModels;
using System.Windows.Controls;

namespace CRMS.Views;

public partial class BookingPage : Page
{
    public BookingPage()
    {
        InitializeComponent();
        DataContext = new BookingViewModel();
    }
}
