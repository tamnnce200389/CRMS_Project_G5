/* TV6 - Booking concurrency / expiry notes
   BookingService currently uses SQL Server SERIALIZABLE transactions and the
   IX_Bookings_VehicleRange index for overlap checks. Run this script against
   the existing CRMS database only after verifying status values in your schema.
*/
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Bookings_VehicleRange' AND object_id = OBJECT_ID('dbo.Bookings'))
    CREATE INDEX IX_Bookings_VehicleRange ON dbo.Bookings(VehicleId, StartAt, EndAt);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UX_Bookings_RequestKey' AND object_id = OBJECT_ID('dbo.Bookings'))
    CREATE UNIQUE INDEX UX_Bookings_RequestKey ON dbo.Bookings(RequestKey);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UX_Bookings_Code' AND object_id = OBJECT_ID('dbo.Bookings'))
    CREATE UNIQUE INDEX UX_Bookings_Code ON dbo.Bookings(BookingCode);
GO
/* Expiration is also invoked from BookingService when reading/creating bookings.
   Optional SQL Agent job can execute this procedure every minute. */
CREATE OR ALTER PROCEDURE dbo.usp_ExpirePendingBookings
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    BEGIN TRANSACTION;
    DECLARE @Expired TABLE (BookingId BIGINT PRIMARY KEY);
    UPDATE dbo.Bookings WITH (UPDLOCK, READPAST, ROWLOCK)
       SET BookingStatus = 'Expired', UpdatedAt = GETDATE()
       OUTPUT inserted.BookingId INTO @Expired(BookingId)
     WHERE BookingStatus = 'PendingDeposit' AND DepositDeadline <= GETDATE();
    UPDATE bv SET RedemptionStatus = 'Released'
      FROM dbo.BookingVoucher bv JOIN @Expired e ON e.BookingId = bv.BookingId;
    INSERT dbo.BookingStatusHistory(BookingId, OldStatus, NewStatus, ChangedAt, ChangeNote)
      SELECT BookingId, 'PendingDeposit', 'Expired', GETDATE(), 'Hết hạn thanh toán cọc' FROM @Expired;
    COMMIT TRANSACTION;
END;
GO
